
Strategic Strike Trading - Static Website (Dark Gold Theme) - Advanced Version (Option 2)

What's inside:
- index.html    -> Main website (static)
- styles.css    -> CSS styling (dark gold theme)
- script.js     -> Simple interactive behaviors (demo values, mailto contact)
- README.txt    -> This file

How to use:
1) Download and unzip the folder.
2) Open index.html in any browser to view the site locally (works on phone or PC).
3) To publish online for free:
   - You can use GitHub Pages (create a GitHub repo, push the files, enable Pages).
   - Or upload the folder to Netlify / Vercel as a static site (drag & drop).
4) Contact form behavior:
   - The contact form uses a mailto: link to strategicstriketrading@gmail.com (opens your email client).
   - The demo request form shows a placeholder alert. When ready to accept leads, replace with a real form backend like Formspree or Netlify Forms.
5) To customize:
   - Edit text in index.html (founder name, phone, tagline).
   - Edit styles in styles.css for colors and spacing.
   - Edit script.js to change demo performance numbers.

Need help deploying? Reply and I will guide you step-by-step to publish this site for free on GitHub Pages / Netlify / Vercel.
