// Simple demo interactions for the static site
document.addEventListener('DOMContentLoaded', function(){
  // Demo: animate current capital from start to current (placeholder)
  const start = 100000;
  let current = 100000; // same initially
  const currentEl = document.getElementById('currentCapital');
  const thisMonthEl = document.getElementById('thisMonth');
  const winRateEl = document.getElementById('winRate');
  const maxDdEl = document.getElementById('maxDd');

  // Fake demo updates (you can edit these numbers to show progress)
  const demo = {
    current: 100000,
    thisMonth: 0,
    winRate: 0,
    maxDd: 0
  };

  // Update UI
  function refresh(){
    currentEl.textContent = '₹' + demo.current.toLocaleString('en-IN');
    thisMonthEl.textContent = '₹' + demo.thisMonth.toLocaleString('en-IN');
    winRateEl.textContent = demo.winRate + '%';
    maxDdEl.textContent = demo.maxDd + '%';
  }
  refresh();

  // Demo form handling: sends an email link (mailto) and shows toast
  const contactForm = document.getElementById('contactForm');
  if(contactForm){
    contactForm.addEventListener('submit', function(e){
      e.preventDefault();
      const data = new FormData(contactForm);
      const name = data.get('name') || 'No name';
      const email = data.get('email') || 'no-email';
      const message = data.get('message') || '';
      const subject = encodeURIComponent('Website inquiry from ' + name);
      const body = encodeURIComponent('From: ' + name + ' ('+email+')\n\n' + message);
      window.location.href = 'mailto:strategicstriketrading@gmail.com?subject=' + subject + '&body=' + body;
    });
  }

  const demoForm = document.getElementById('demoForm');
  if(demoForm){
    demoForm.addEventListener('submit', function(e){
      e.preventDefault();
      alert('Thanks — demo request received. We will contact you on WhatsApp/Email. (This is a demo placeholder).');
    });
  }
});
